package com.rpgcraft.event;

import com.rpgcraft.classsystem.ClassManager;
import com.rpgcraft.command.ModCommands;
import com.rpgcraft.data.PlayerData;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class ModEvents {

    public static void register() {
        ModCommands.register();

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayerEntity player = handler.getPlayer();
            PlayerData data = ClassManager.getData(player);

            server.execute(() -> {
                if (!data.hasChosenClass()) {
                    player.sendMessage(Text.literal("§6§l════════════════════════════════"), false);
                    player.sendMessage(Text.literal("§6§l       ✦ RPG CRAFT ✦"), false);
                    player.sendMessage(Text.literal("§eVocê ainda não escolheu uma classe!"), false);
                    player.sendMessage(Text.literal("§7Digite §f/rpg select <classe> §7para escolher."), false);
                    player.sendMessage(Text.literal("§7Classes: §cespadachim§7, §6artesao§7, §aarqueiro§7,"), false);
                    player.sendMessage(Text.literal("§7         §dmago§7, §bmineiro§7, §8assassino"), false);
                    player.sendMessage(Text.literal("§6§l════════════════════════════════"), false);
                } else {
                    player.sendMessage(Text.literal("§6§l[RPG CRAFT] §aBem-vindo de volta, ")
                            .append(data.getPlayerClass().getStyledName())
                            .append(Text.literal(" §7Nv. §f" + data.getLevel())), false);
                }
            });
        });
    }
}
