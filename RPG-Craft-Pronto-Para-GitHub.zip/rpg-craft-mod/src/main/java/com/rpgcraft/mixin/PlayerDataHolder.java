package com.rpgcraft.mixin;

import com.rpgcraft.data.PlayerData;

public interface PlayerDataHolder {
    PlayerData rpgcraft$getData();
    void rpgcraft$setData(PlayerData data);
}
