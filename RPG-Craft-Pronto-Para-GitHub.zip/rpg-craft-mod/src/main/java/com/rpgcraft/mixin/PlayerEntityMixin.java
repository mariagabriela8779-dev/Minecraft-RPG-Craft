package com.rpgcraft.mixin;

import com.rpgcraft.data.PlayerData;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PlayerEntity.class)
public abstract class PlayerEntityMixin implements PlayerDataHolder {

    @Unique
    private PlayerData rpgcraft$data = PlayerData.createDefault();

    @Override
    public PlayerData rpgcraft$getData() {
        return this.rpgcraft$data;
    }

    @Override
    public void rpgcraft$setData(PlayerData data) {
        this.rpgcraft$data = data;
    }

    @Inject(method = "writeCustomDataToNbt", at = @At("RETURN"))
    private void rpgcraft$writeData(NbtCompound nbt, CallbackInfo ci) {
        nbt.put(PlayerData.NBT_KEY, this.rpgcraft$data.writeNbt());
    }

    @Inject(method = "readCustomDataFromNbt", at = @At("RETURN"))
    private void rpgcraft$readData(NbtCompound nbt, CallbackInfo ci) {
        if (nbt.contains(PlayerData.NBT_KEY)) {
            this.rpgcraft$data.readNbt(nbt.getCompound(PlayerData.NBT_KEY));
        }
    }
}
