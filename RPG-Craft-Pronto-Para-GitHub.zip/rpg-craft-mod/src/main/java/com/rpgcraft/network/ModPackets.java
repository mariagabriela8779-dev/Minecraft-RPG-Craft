package com.rpgcraft.network;

import com.rpgcraft.RPGCraftMod;
import com.rpgcraft.classsystem.ClassManager;
import com.rpgcraft.classsystem.PlayerClass;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

public class ModPackets {
    public static final Identifier SELECT_CLASS = new Identifier(RPGCraftMod.MOD_ID, "select_class");

    public static void registerC2SPackets() {
        ServerPlayNetworking.registerGlobalReceiver(SELECT_CLASS, (server, player, handler, buf, responseSender) -> {
            String classId = buf.readString();
            server.execute(() -> {
                PlayerClass selected = PlayerClass.fromId(classId);
                if (selected != PlayerClass.NONE) {
                    ClassManager.setClass(player, selected);
                }
            });
        });
    }

    public static PacketByteBuf createSelectClassPacket(String classId) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeString(classId);
        return buf;
    }
}
