package com.rpgcraft.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.rpgcraft.classsystem.ClassManager;
import com.rpgcraft.classsystem.PlayerClass;
import com.rpgcraft.data.PlayerData;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

public class ModCommands {

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            registerRpgCommand(dispatcher);
        });
    }

    private static void registerRpgCommand(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(CommandManager.literal("rpg")
                // /rpg select <classe>
                .then(CommandManager.literal("select")
                        .then(CommandManager.argument("classe", StringArgumentType.word())
                                .executes(ctx -> {
                                    ServerPlayerEntity player = ctx.getSource().getPlayer();
                                    if (player == null) return 0;

                                    String classId = StringArgumentType.getString(ctx, "classe");
                                    PlayerClass selected = PlayerClass.fromId(classId);

                                    if (selected == PlayerClass.NONE) {
                                        player.sendMessage(Text.literal("§cClasse inválida! Use: espadachim, artesao, arqueiro, mago, mineiro, assassino"), false);
                                        return 0;
                                    }

                                    PlayerData data = ClassManager.getData(player);
                                    if (data.hasChosenClass()) {
                                        player.sendMessage(Text.literal("§cVocê já escolheu uma classe! (Troca de classe será adicionada em breve)"), false);
                                        return 0;
                                    }

                                    ClassManager.setClass(player, selected);
                                    return 1;
                                })
                        )
                        .executes(ctx -> {
                            ServerPlayerEntity player = ctx.getSource().getPlayer();
                            if (player == null) return 0;
                            player.sendMessage(Text.literal("§eUse: §f/rpg select <classe>"), false);
                            player.sendMessage(Text.literal("§7Classes: §cespadachim§7, §6artesao§7, §aarqueiro§7, §dmago§7, §bmineiro§7, §8assassino"), false);
                            return 1;
                        })
                )
                // /rpg class
                .then(CommandManager.literal("class")
                        .executes(ctx -> {
                            ServerPlayerEntity player = ctx.getSource().getPlayer();
                            if (player == null) return 0;

                            PlayerData data = ClassManager.getData(player);
                            if (data.hasChosenClass()) {
                                player.sendMessage(Text.literal("§6Sua classe atual: ")
                                        .append(data.getPlayerClass().getStyledName())
                                        .append(Text.literal(" §7| Nível: §f" + data.getLevel())
                                                .append(Text.literal(" §7| XP: §f" + data.getExperience() + "/" + data.getXpForNextLevel())
                                                        .append(Text.literal(" §7| Skill Points: §e" + data.getSkillPoints())))), false);
                            } else {
                                player.sendMessage(Text.literal("§eVocê ainda não escolheu uma classe! Use §f/rpg select <classe>"), false);
                            }
                            return 1;
                        })
                )
                // /rpg stats
                .then(CommandManager.literal("stats")
                        .executes(ctx -> {
                            ServerPlayerEntity player = ctx.getSource().getPlayer();
                            if (player == null) return 0;
                            PlayerData data = ClassManager.getData(player);

                            player.sendMessage(Text.literal("§6§l══════ RPG CRAFT STATS ══════"), false);
                            player.sendMessage(Text.literal("§7Classe: ").append(data.getPlayerClass().getStyledName()), false);
                            player.sendMessage(Text.literal("§7Nível: §f" + data.getLevel() + " §8| §7XP: §f" + data.getExperience() + "/" + data.getXpForNextLevel()), false);
                            player.sendMessage(Text.literal("§7Skill Points: §e" + data.getSkillPoints()), false);
                            player.sendMessage(Text.literal("§6§l════════════════════════════"), false);
                            return 1;
                        })
                )
                // /rpg help
                .then(CommandManager.literal("help")
                        .executes(ctx -> {
                            ServerPlayerEntity player = ctx.getSource().getPlayer();
                            if (player == null) return 0;
                            player.sendMessage(Text.literal("§6§l[RPG CRAFT] Comandos:"), false);
                            player.sendMessage(Text.literal("§e/rpg select <classe> §7- Escolher classe (primeira vez)"), false);
                            player.sendMessage(Text.literal("§e/rpg class §7- Ver sua classe atual"), false);
                            player.sendMessage(Text.literal("§e/rpg stats §7- Ver estatísticas completas"), false);
                            player.sendMessage(Text.literal("§e/rpg help §7- Esta mensagem"), false);
                            return 1;
                        })
                )
        );
    }
}
