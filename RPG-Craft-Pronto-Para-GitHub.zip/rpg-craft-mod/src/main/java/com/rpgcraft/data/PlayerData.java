package com.rpgcraft.data;

import com.rpgcraft.classsystem.PlayerClass;
import net.minecraft.nbt.NbtCompound;

public class PlayerData {
    public static final String NBT_KEY = "RPGCraftData";

    private PlayerClass playerClass = PlayerClass.NONE;
    private int level = 1;
    private int experience = 0;
    private int skillPoints = 0;
    private boolean hasChosenClass = false;

    // Skills levels (0 = locked)
    private int skill1 = 0;
    private int skill2 = 0;
    private int skill3 = 0;
    private int ultimate = 0;

    public PlayerClass getPlayerClass() {
        return playerClass;
    }

    public void setPlayerClass(PlayerClass playerClass) {
        this.playerClass = playerClass;
        this.hasChosenClass = true;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = Math.max(1, Math.min(100, level));
    }

    public int getExperience() {
        return experience;
    }

    public void addExperience(int amount) {
        this.experience += amount;
        checkLevelUp();
    }

    public int getSkillPoints() {
        return skillPoints;
    }

    public void setSkillPoints(int skillPoints) {
        this.skillPoints = Math.max(0, skillPoints);
    }

    public boolean hasChosenClass() {
        return hasChosenClass;
    }

    public void setHasChosenClass(boolean hasChosenClass) {
        this.hasChosenClass = hasChosenClass;
    }

    public int getSkill1() { return skill1; }
    public void setSkill1(int v) { this.skill1 = v; }
    public int getSkill2() { return skill2; }
    public void setSkill2(int v) { this.skill2 = v; }
    public int getSkill3() { return skill3; }
    public void setSkill3(int v) { this.skill3 = v; }
    public int getUltimate() { return ultimate; }
    public void setUltimate(int v) { this.ultimate = v; }

    private void checkLevelUp() {
        int required = getXpForNextLevel();
        while (experience >= required && level < 100) {
            experience -= required;
            level++;
            skillPoints += 2; // 2 pontos por nível
            required = getXpForNextLevel();
        }
    }

    public int getXpForNextLevel() {
        return 100 + (level * 50) + (level * level * 5);
    }

    public NbtCompound writeNbt() {
        NbtCompound nbt = new NbtCompound();
        nbt.putString("Class", playerClass.getId());
        nbt.putInt("Level", level);
        nbt.putInt("Experience", experience);
        nbt.putInt("SkillPoints", skillPoints);
        nbt.putBoolean("HasChosenClass", hasChosenClass);
        nbt.putInt("Skill1", skill1);
        nbt.putInt("Skill2", skill2);
        nbt.putInt("Skill3", skill3);
        nbt.putInt("Ultimate", ultimate);
        return nbt;
    }

    public void readNbt(NbtCompound nbt) {
        if (nbt.contains("Class")) {
            this.playerClass = PlayerClass.fromId(nbt.getString("Class"));
        }
        this.level = nbt.contains("Level") ? nbt.getInt("Level") : 1;
        this.experience = nbt.contains("Experience") ? nbt.getInt("Experience") : 0;
        this.skillPoints = nbt.contains("SkillPoints") ? nbt.getInt("SkillPoints") : 0;
        this.hasChosenClass = nbt.contains("HasChosenClass") && nbt.getBoolean("HasChosenClass");
        this.skill1 = nbt.contains("Skill1") ? nbt.getInt("Skill1") : 0;
        this.skill2 = nbt.contains("Skill2") ? nbt.getInt("Skill2") : 0;
        this.skill3 = nbt.contains("Skill3") ? nbt.getInt("Skill3") : 0;
        this.ultimate = nbt.contains("Ultimate") ? nbt.getInt("Ultimate") : 0;
    }

    public static PlayerData createDefault() {
        return new PlayerData();
    }
}
