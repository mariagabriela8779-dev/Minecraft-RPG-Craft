package com.rpgcraft.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;

public class RPGCraftClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // A tela será aberta via evento no servidor/cliente sincronizado
    }
}
