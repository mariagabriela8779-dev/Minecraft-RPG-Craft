package com.rpgcraft.client;

import com.rpgcraft.classsystem.PlayerClass;
import com.rpgcraft.network.ModPackets;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class ClassSelectionScreen extends Screen {

    private PlayerClass hoveredClass = null;

    public ClassSelectionScreen() {
        super(Text.literal("Escolha sua Classe").formatted(Formatting.GOLD, Formatting.BOLD));
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int startY = 60;
        int buttonWidth = 160;
        int buttonHeight = 24;
        int spacing = 28;

        PlayerClass[] classes = {
            PlayerClass.ESPADACHIM,
            PlayerClass.ARTESAO,
            PlayerClass.ARQUEIRO,
            PlayerClass.MAGO,
            PlayerClass.MINEIRO,
            PlayerClass.ASSASSINO
        };

        for (int i = 0; i < classes.length; i++) {
            final PlayerClass pc = classes[i];
            int y = startY + (i * spacing);

            this.addDrawableChild(ButtonWidget.builder(
                    Text.literal("▶ " + pc.getDisplayName()).formatted(pc.getColor()),
                    button -> selectClass(pc)
            ).dimensions(centerX - buttonWidth / 2, y, buttonWidth, buttonHeight).build());
        }

        // Botão de fechar (só se já tiver classe, mas aqui é primeira vez)
        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Fechar").formatted(Formatting.GRAY),
                button -> this.close()
        ).dimensions(centerX - 50, this.height - 40, 100, 20).build());
    }

    private void selectClass(PlayerClass playerClass) {
        ClientPlayNetworking.send(ModPackets.SELECT_CLASS, ModPackets.createSelectClassPacket(playerClass.getId()));
        this.close();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context);

        // Título
        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("✦ RPG CRAFT ✦").formatted(Formatting.GOLD, Formatting.BOLD),
                this.width / 2, 15, 0xFFFFFF);

        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("Escolha sua classe e inicie sua jornada épica"),
                this.width / 2, 32, 0xAAAAAA);

        // Descrição da classe hover (simples)
        if (hoveredClass != null) {
            context.drawCenteredTextWithShadow(this.textRenderer,
                    Text.literal(hoveredClass.getDescription()).formatted(Formatting.YELLOW),
                    this.width / 2, this.height - 70, 0xFFFFFF);
        }

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false; // força a escolha
    }
}
